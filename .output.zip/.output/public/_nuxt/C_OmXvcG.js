import{aI as o}from"./CvbpmZ9T.js";const p=o("/logo.png");export{p as _};
