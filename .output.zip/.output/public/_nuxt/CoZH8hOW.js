import{k as o}from"./CvbpmZ9T.js";const r=()=>o("color-mode").value;export{r as u};
