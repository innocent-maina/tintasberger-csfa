import { d as defineEventHandler, u as useRuntimeConfig, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { createClient } from '@supabase/supabase-js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const register = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const supabase = createClient(
    runtimeConfig.public.supabaseUrl,
    runtimeConfig.public.supabaseServiceRoleKey
  );
  const {
    email,
    password,
    full_name,
    username,
    phone_number,
    role
  } = await readBody(event);
  if (!email || !password || !full_name || !username || !phone_number || !role) {
    throw createError({
      statusCode: 400,
      message: "Missing required fields"
    });
  }
  try {
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name,
          username,
          phone_number,
          role
        }
      }
    });
    if (authError || !authData.user) {
      throw createError({
        statusCode: 400,
        message: (authError == null ? void 0 : authError.message) || "Registration failed"
      });
    }
    return {
      success: true,
      message: "User registered successfully",
      user: authData.user
    };
  } catch (err) {
    console.error("Registration error:", err);
    return { success: false, message: "Failed to register" };
  }
});

export { register as default };
//# sourceMappingURL=register.mjs.map
