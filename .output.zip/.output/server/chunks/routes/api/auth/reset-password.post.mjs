import { d as defineEventHandler, u as useRuntimeConfig, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { createClient } from '@supabase/supabase-js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const resetPassword_post = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const supabase = createClient(
    runtimeConfig.public.supabaseUrl,
    runtimeConfig.public.supabaseServiceRoleKey
  );
  const body = await readBody(event);
  console.log("Reset Password Body:", body);
  const { token, password } = body;
  console.log("Reset Password Request:", { token, password });
  try {
    if (!token || !password) {
      throw createError({
        statusCode: 400,
        message: "Token and password are required."
      });
    }
    const { error } = await supabase.auth.updateUser(token, {
      password
    });
    if (error) {
      console.error("Error updating password:", error);
      throw createError({ statusCode: 500, message: error.message });
    }
    return { success: true, message: "Password updated successfully." };
  } catch (err) {
    console.error("Error changing password:", err);
    return { success: false, message: `Internal Server Error, ${err}` };
  }
});

export { resetPassword_post as default };
//# sourceMappingURL=reset-password.post.mjs.map
