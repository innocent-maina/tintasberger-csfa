import { d as defineEventHandler, u as useRuntimeConfig, g as getQuery, c as createError } from '../../../nitro/nitro.mjs';
import { createClient } from '@supabase/supabase-js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const customer_page_get = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const supabase = createClient(
    runtimeConfig.public.supabaseUrl,
    runtimeConfig.public.supabaseServiceRoleKey
  );
  const { id } = getQuery(event);
  if (!id) {
    throw createError({ statusCode: 400, message: "Missing customer ID" });
  }
  try {
    const { data: customer, error: customerError } = await supabase.from("customers").select("*").eq("id", id).single();
    if (customerError) {
      throw createError({ statusCode: 500, message: customerError.message });
    }
    const { data: orders, error: ordersError } = await supabase.from("orders").select("*").eq("customer_id", id);
    if (ordersError) {
      throw createError({ statusCode: 500, message: ordersError.message });
    }
    const { data: invoices, error: invoicesError } = await supabase.from("invoices").select("*").eq("customer_id", id);
    if (invoicesError) {
      throw createError({ statusCode: 500, message: invoicesError.message });
    }
    return {
      success: true,
      data: {
        customer,
        orders,
        invoices
      }
    };
  } catch (err) {
    console.error(`Error fetching data for customer ID ${id}:`, err);
    return { success: false, message: "Internal Server Error" };
  }
});

export { customer_page_get as default };
//# sourceMappingURL=customer_page.get.mjs.map
