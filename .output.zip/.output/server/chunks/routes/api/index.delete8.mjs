import { d as defineEventHandler, u as useRuntimeConfig, g as getQuery, c as createError } from '../../nitro/nitro.mjs';
import { createClient } from '@supabase/supabase-js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const index_delete = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const supabase = createClient(
    runtimeConfig.public.supabaseUrl,
    runtimeConfig.public.supabaseServiceRoleKey
  );
  const { id, orderNumber } = getQuery(event);
  if (!id) {
    throw createError({ statusCode: 400, message: "Missing order ID" });
  }
  if (!orderNumber) {
    throw createError({ statusCode: 400, message: "Missing orderNumber" });
  }
  try {
    const subFolders = ["invoices", "progress-images", "order"];
    const allFilePaths = [];
    for (const folder of subFolders) {
      const { data: files, error: listError } = await supabase.storage.from("orders").list(`${orderNumber}/${folder}`, {
        limit: 1e3,
        offset: 0,
        sortBy: { column: "name", order: "asc" }
      });
      if (listError) {
        console.warn(
          `Could not list files for ${orderNumber}/${folder}:`,
          listError.message
        );
        continue;
      }
      console.log("allFilePaths", allFilePaths);
      const filePaths = (files == null ? void 0 : files.map((file) => `${orderNumber}/${folder}/${file.name}`)) || [];
      allFilePaths.push(...filePaths);
    }
    console.log("allFilePaths", allFilePaths);
    if (allFilePaths.length > 0) {
      const { error: deleteFilesError } = await supabase.storage.from("orders").remove(allFilePaths);
      if (deleteFilesError) {
        console.warn(
          `Failed to delete files for order ${orderNumber}:`,
          deleteFilesError.message
        );
      }
    }
    const { error: deleteOrderError } = await supabase.from("orders").delete().eq("id", id);
    if (deleteOrderError) {
      throw createError({ statusCode: 500, message: deleteOrderError.message });
    }
    return {
      success: true,
      message: `Order ${orderNumber} and its files have been deleted.`,
      allFilePaths
    };
  } catch (error) {
    const isForeignKeyError = typeof error.message === "string" && error.message.includes("violates foreign key constraint");
    return {
      success: false,
      message: isForeignKeyError ? "Cannot delete this order because it has related invoices. Please delete the invoices first." : "An unexpected error occurred while deleting the order.",
      details: error.message
    };
  }
});

export { index_delete as default };
//# sourceMappingURL=index.delete8.mjs.map
