import { d as defineEventHandler, c as createError } from '../../nitro/nitro.mjs';
import { createClient } from '@supabase/supabase-js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const index_get = defineEventHandler(async (event) => {
  const supabase = createClient(
    process.env.NUXT_SUPABASE_URL,
    process.env.NUXT_SUPABASE_ANON_KEY
    // Service Role Key (Sensitive)
  );
  if (!supabase) {
    throw createError({
      statusCode: 500,
      message: "Failed to initialize Supabase client."
    });
  }
  try {
    const bucketName = "familyguy";
    const { data, error } = await supabase.storage.from(bucketName).list();
    if (error) throw createError({ statusCode: 500, message: error.message });
    const files = data.map((file) => ({
      name: file.name,
      url: `${process.env.NUXT_SUPABASE_URL}/storage/v1/object/public/${bucketName}/${file.name}`
    }));
    return { success: true, files };
  } catch (err) {
    console.error("Error fetching storage files:", err);
    return { success: false, message: "Internal Server Error", err };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get10.mjs.map
