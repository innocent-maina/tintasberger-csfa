import { d as defineEventHandler, u as useRuntimeConfig, g as getQuery, c as createError, r as readBody } from '../../nitro/nitro.mjs';
import { createClient } from '@supabase/supabase-js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const index_put = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const supabase = createClient(
    runtimeConfig.public.supabaseUrl,
    runtimeConfig.public.supabaseServiceRoleKey
  );
  const { id } = getQuery(event);
  if (!id) {
    throw createError({ statusCode: 400, message: "Missing user ID" });
  }
  const updateData = await readBody(event);
  if (!updateData) {
    throw createError({ statusCode: 400, message: "Missing update data" });
  }
  try {
    const { data, error } = await supabase.from("users").update(updateData).eq("id", id).select().single();
    if (error) {
      console.error(`Error updating user with id ${id}:`, error.message);
      return { success: false, data: error.message };
    }
    return { success: true, data };
  } catch (err) {
    console.error(`Error updating user with id ${id}:`, err);
    return { success: false, data: "Internal Server Error" };
  }
});

export { index_put as default };
//# sourceMappingURL=index.put12.mjs.map
