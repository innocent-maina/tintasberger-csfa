import { d as defineEventHandler, u as useRuntimeConfig, c as createError, g as getQuery } from '../../../nitro/nitro.mjs';
import { createClient } from '@supabase/supabase-js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const user_get = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const supabase = createClient(
    runtimeConfig.public.supabaseUrl,
    runtimeConfig.public.supabaseServiceRoleKey
  );
  if (!supabase) {
    throw createError({
      statusCode: 500,
      message: "Failed to initialize Supabase client."
    });
  }
  const { user_id } = getQuery(event);
  if (!user_id) {
    throw createError({
      statusCode: 400,
      message: "User ID is required."
    });
  }
  try {
    const { data, error } = await supabase.from("notifications").select("*, user:users(full_name)").eq("user_id", user_id).order("created_at", { ascending: false });
    if (error) {
      throw createError({ statusCode: 500, message: error.message });
    }
    return { success: true, data };
  } catch (err) {
    console.error("Error fetching user notifications:", err);
    return { success: false, message: "Failed to fetch user notifications." };
  }
});

export { user_get as default };
//# sourceMappingURL=user.get.mjs.map
