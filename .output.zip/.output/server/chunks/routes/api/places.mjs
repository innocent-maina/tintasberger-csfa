import { d as defineEventHandler, g as getQuery, c as createError, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const places = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const runtimeConfig = useRuntimeConfig();
  if (!query.input) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing input parameter"
    });
  }
  const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(
    query.input
  )}&key=${runtimeConfig.public.mapsApiKey}`;
  try {
    const response = await $fetch(url);
    return response;
  } catch (error) {
    console.error("Google Places API error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to fetch from Google Places API"
    });
  }
});

export { places as default };
//# sourceMappingURL=places.mjs.map
